var tec_default_style = document.createElement("link");
tec_default_style.rel = "stylesheet";
tec_default_style.href = "/wp-content/plugins/te-custom-mods/includes/css/tec_default.css?v1.0";
tec_default_style.id = "tec_default_stylesheet";
document.head.appendChild(tec_default_style);